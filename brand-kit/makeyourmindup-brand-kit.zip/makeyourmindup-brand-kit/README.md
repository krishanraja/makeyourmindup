# makeyourmindup brand kit, v1.5

5 October 2026. Everything here is built from the live cover at makeyourmindup.ai by
`npm run brand-kit` in `apps/cover`, so it matches what readers see.

**Download:** `makeyourmindup-brand-kit.zip` in this folder holds all of it.

## Start here

Open `guidelines/makeyourmindup-brand-book.pdf`. Seventeen pages: the name, the
logo, colour, type, the kit of parts, the three sections, texture and motion,
the felt-robot photography and its stamps, voice, and the brand in use.

## What is inside

| Folder | What | Use it for |
|---|---|---|
| `guidelines/` | The brand book as PDF and HTML | Briefing anyone who touches the brand |
| `logos/stacked/` | The primary lockup, transparent and on ink | Covers, first screens, big moments |
| `logos/horizontal/` | The one-line lockup | Navigation, footers, email headers |
| `logos/mark/` | The block mark, app icons, a 1024 avatar | Avatars, favicons, social profiles |
| `colours/` | Every colour with hex, RGB and its one job | Quick reference |
| `tokens/` | CSS variables, JSON tokens, a Tailwind preset | Building anything on screen |
| `fonts/` | Anton, Archivo, Fraunces, IBM Plex Mono, each with its licence | Installing the type |
| `applications/` | Social card, Substack cover, email banner, site screenshots | Seeing it done right |
| `photography/` | The felt robot lying down and standing up, as sources and as cut onto ink with their threads, plus the editor's two photos | Anything that needs the robot or Krish |

## The five rules that matter most

1. The name is one word, all lowercase: makeyourmindup.
2. The sections run follow.the.money, under.the.hood, mind.the.gap. Monday,
   Wednesday, Friday, in that order, every time.
3. Every colour has one job. Type on a colour block is always ink.
4. The logo only sits on ink, level, untouched. A light version does not exist
   yet.
5. No em dashes, no exclamation marks, British spelling, and no sermons.

## Fonts

All four families are Google Fonts under the SIL Open Font License: free to
use, embed and share, commercially too. The licence sits next to each one.
