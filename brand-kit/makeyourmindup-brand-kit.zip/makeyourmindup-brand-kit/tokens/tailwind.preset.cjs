// makeyourmindup Tailwind preset, v1.0. Add to presets: [require('./tailwind.preset.cjs')]
module.exports = {
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: '#0C1512', deep: '#070D0B', soft: '#16221D' },
        mint: '#7EF0C0',
        cream: '#F4EFE4',
        coral: '#FF6A4D',
        butter: '#FFD84D',
        lilac: '#B7A6FF',
      },
      fontFamily: {
        display: ['Anton', 'Arial Narrow', 'sans-serif'],
        sans: ['Archivo', 'system-ui', 'sans-serif'],
        serif: ['Fraunces', 'Georgia', 'serif'],
        mono: ['IBM Plex Mono', 'ui-monospace', 'monospace'],
      },
      boxShadow: { brutal: '6px 6px 0 0 #0C1512', 'brutal-sm': '3px 3px 0 0 #0C1512' },
      maxWidth: { page: '1400px' },
    },
  },
}
